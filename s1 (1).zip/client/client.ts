import * as web3 from "@solana/web3.js";
import * as anchor from "@coral-xyz/anchor";
import * as anchor from "@coral-xyz/anchor";
import type { HelloAnchor } from "../target/types/hello_anchor";

// Configure the client to use the local cluster
anchor.setProvider(anchor.AnchorProvider.env());

const program = anchor.workspace.HelloAnchor as anchor.Program<HelloAnchor>;


async function main() {
    try {
        // Configurar el proveedor
        const provider = anchor.AnchorProvider.env();
        anchor.setProvider(provider);

        const programId = new anchor.web3.PublicKey("GEmSaJF2UT1YvHejiDP7ozb25J7M1dGQUW6QFz8JD6Gj"); // Reemplaza con tu Program ID
        const idl = await anchor.Program.fetchIdl(programId, provider);
        const program = new anchor.Program(idl!, programId, provider);

        // Crear nueva cuenta
        const miCuenta = anchor.web3.Keypair.generate();
        console.log("Cuenta creada:", miCuenta.publicKey.toBase58());

        // Solicitar Airdrop
        const signature = await provider.connection.requestAirdrop(provider.wallet.publicKey, 1e9);
        await provider.connection.confirmTransaction(signature);

        // Inicializar la cuenta
        console.log("Inicializando la cuenta...");
        await program.methods
            .initialize("¡Hola, Solana!") // Mensaje inicial
            .accounts({
                miCuenta: miCuenta.publicKey,
                user: provider.wallet.publicKey,
                systemProgram: anchor.web3.SystemProgram.programId,
            })
            .signers([miCuent
