use anchor_lang::prelude::*;

// This is your program's public key and it will update
// automatically when you build the project.
declare_id!("GEmSaJF2UT1YvHejiDP7ozb25J7M1dGQUW6QFz8JD6Gj");

#[program]
mod hello_anchor {
    use super::*;
    pub fn initialize(ctx: Context<Initialize>, message: String) -> Result<()> {
        require!(message.len() <= 150, ErrorCode::MessageTooLong);
        ctx.accounts.new_account.message = message;
        msg!("Message stored: {}!", ctx.accounts.new_account.message); // Message will show up in the tx logs
        Ok(())
    }

    pub fn update_message(ctx: Context<UpdateMessage>, new_message: String) -> Result<()> {
        require!(new_message.len() <= 150, ErrorCode::MessageTooLong);

        // Update the message in the account
        ctx.accounts.new_account.message = new_message;
        msg!("Message updated to: {}", ctx.accounts.new_account.message);
        Ok(())
    }
}

#[derive(Accounts)]
pub struct Initialize<'info> {
    // We must specify the space in order to initialize an account.
    // First 8 bytes are default account discriminator,
    // next 8 bytes come from NewAccount.message.
    // (u64 = 64 bits unsigned integer = 8 bytes)
    #[account(init, payer = signer, space = 8 + 4 + 150)]
    pub new_account: Account<'info, NewAccount>,
    #[account(mut)]
    pub signer: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct UpdateMessage<'info> {
    #[account(mut)]
    pub new_account: Account<'info, NewAccount>,
    #[account(mut)]
    pub signer: Signer<'info>,
}

#[account]
pub struct NewAccount {
    pub message: String
}

#[error_code]
pub enum ErrorCode {
    #[msg("El mensaje excede 150 caracteres.")]
    MessageTooLong,
}


